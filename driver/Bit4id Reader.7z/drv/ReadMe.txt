ACR38/100/122 PC/SC Driver Installer (MSI)
Advanced Card Systems Ltd.



Contents
----------------

   1. Release Notes
   2. Installation
   3. History
   4. File Contents
   5. Limitations
   6. Support



1. Release Notes
----------------

Version: 1.1.3.0
Release Date: 18/04/2012

1. Supported Operating Systems
    Windows 98
    Windows ME
    Windows NT 4.0
    Windows 2000
    Windows XP 32-bit
    Windows XP 64-bit
    Windows Server 2003 32-bit
    Windows Server 2003 64-bit
    Windows Server 2003 R2 32-bit
    Windows Server 2003 R2 64-bit
    Windows Vista 32-bit
    Windows Vista 64-bit
    Windows Server 2008 32-bit
    Windows Server 2008 64-bit
    Windows Server 2008 R2 64-bit
    Windows 7 32-bit
    Windows 7 64-bit

2. Supported Languages
    Arabic
    Chinese (Simplified)
    Chinese (Traditional)
    Czech
    Danish
    Dutch
    English
    Finnish
    French
    German
    Greek
    Hebrew
    Hungarian
    Italian
    Japanese
    Korean
    Norwegian
    Polish
    Portuguese (Brazil)
    Portuguese (Portugal)
    Russian
    Spanish
    Swedish
    Turkish
    Ukrainian

3. Supported readers
    ACR38U/T/DT/ET/F/K
    ACR38U-CCID
    ACR100-CCID
    ACR122U/T
    ACR122U-SAM

4. Driver Versions
                            ACR38U      ACR122U     ACSCCID
    Windows 98/ME           v0.9.0.8    v1.1.6.3    v1.1.6.5
    Windows NT 4.0          v1.0.0.1    N/A         N/A
    Windows 2000 or later   v1.1.6.2    v1.1.6.3    v1.1.6.5

5. Command Options

    Setup [option]

    /q          Quiet mode
    /x          Uninstall driver
    /norestart  Do not restart after driver installation/uninstallation

    Exit Codes:

    ERROR_SUCCESS                       0x00000000  Success
    ERROR_FILE_NOT_FOUND                0x00000002  File not found
    ERROR_NOT_ENOUGH_MEMORY             0x00000008  Not enough memory
    SETUP_ERROR_OS_NOT_SUPPORTED        0x20000001  Operating system is not supported
    SETUP_ERROR_WINNT4_SP6_REQUIRED     0x20000002  Windows NT 4.0 Service Pack 6 is required
    SETUP_ERROR_UNEXPECTED              0x20000003  Unexpected error
    SETUP_ERROR_MSI2_REQUIRED           0x20000004  Windows Installer 2.0 is required
    SETUP_ERROR_MSI_LOCATION_NOT_FOUND  0x20000005  Cannot find the location of Windows Installer

    Note: Other error codes are defined in Windows API and MSI.



2. Installation
---------------

1. Before running the Setup program, please unplug the reader first.
2. Double click the "Setup.exe" program icon to launch the installer. If your system does not have installed Windows Installer 2.0 or above, you will receive a warning message and you need to go to Windows Update to update your system.
3. Follow the on-screen instructions to install the driver to the system.
4. After the installation is completed, please plug the reader to the system.
5. To remove the driver, please go to "Add or Remove Programs" in Control Panel.



3. History
----------

v1.0.0.0 (2/1/2008)
1. New Release
2. Support driver installation in Windows 2000/XP/Vista 32-bit or 64-bit.

v1.1.0.0 (24/6/2008)
1. Support driver installation in Windows 98/ME/NT4/2000/XP/Server2003/Vista/Server2008 32-bit or 64-bit.
2. Support multi-lingual user interface.
3. Add a Uninstall shortcut for easy driver uninstallation.
4. Fix the registry problem in "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography\Calais\Readers" if the LOCAL SERVICE permission is lost.
5. Fix the Smart Service problem if it is not running or it is disabled.

v1.1.0.0 (17/3/2009)
1. Remove program group from Start Menu.
2. Update driver to v1.1.6.0.
3. Add silent mode installation.

v1.1.0.0 (28/7/2009)
1. Update driver to v1.1.6.1.

v1.1.1.0 (11/11/2009)
1. Add ACR122U (v1.1.6.2) and ACSCCID (v1.1.6.4) drivers.

v1.1.2.0 (28/1/2010)
1. Update ACR38U driver to v1.1.6.2.
2. Update ACR122U driver to v1.1.6.3.
3. Update ACSCCID driver to v1.1.6.5.

v1.1.2.0 (27/2/2010)
1. Update UI.

v1.1.3.0 (18/04/2012)
1. Update UI


4. File Contents
----------------

|   ReadMe.txt
|   Setup.exe
|
+---redist
|       InstMsiA.exe
|       InstMsiW.exe
|
+---x64
|       ACR38_100_122_PCSC_Driver.msi
|       Arabic.mst
|       Chinese (Simplified).mst
|       Chinese (Traditional).mst
|       Czech.mst
|       Danish.mst
|       Dutch.mst
|       Finnish.mst
|       French.mst
|       German.mst
|       Greek.mst
|       Hebrew.mst
|       Hungarian.mst
|       Italian.mst
|       Japanese.mst
|       Korean.mst
|       Norwegian.mst
|       Polish.mst
|       Portuguese (Brazil).mst
|       Portuguese (Portugal).mst
|       Russian.mst
|       Spanish.mst
|       Swedish.mst
|       Turkish.mst
|       Ukrainian.mst
|
+---x86
|       ACR38_100_122_PCSC_Driver.msi
|       Arabic.mst
|       Chinese (Simplified).mst
|       Chinese (Traditional).mst
|       Czech.mst
|       Danish.mst
|       Dutch.mst
|       Finnish.mst
|       French.mst
|       German.mst
|       Greek.mst
|       Hebrew.mst
|       Hungarian.mst
|       Italian.mst
|       Japanese.mst
|       Korean.mst
|       Norwegian.mst
|       Polish.mst
|       Portuguese (Brazil).mst
|       Portuguese (Portugal).mst
|       Russian.mst
|       Spanish.mst
|       Swedish.mst
|       Turkish.mst
|       Ukrainian.mst
|
\---x86_nonwin2k
        ACR38_100_122_PCSC_Driver.msi
        Arabic.mst
        Chinese (Simplified).mst
        Chinese (Traditional).mst
        Czech.mst
        Danish.mst
        Dutch.mst
        Finnish.mst
        French.mst
        German.mst
        Greek.mst
        Hebrew.mst
        Hungarian.mst
        Italian.mst
        Japanese.mst
        Korean.mst
        Norwegian.mst
        Polish.mst
        Portuguese (Brazil).mst
        Portuguese (Portugal).mst
        Russian.mst
        Spanish.mst
        Swedish.mst
        Turkish.mst
        Ukrainian.mst



5. Limitations
--------------

For Windows NT 4.0, please update to Service Pack 6 before running the installer.



6. Support
----------

In case of problem, please contact ACS through:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286



-----------------------------------------------------------------


Copyright 
Copyright by Advanced Card Systems Ltd. (ACS) No part of this reference manual may be reproduced or transmitted in any from without the expressed, written permission of ACS. 

Notice 
Due to rapid change in technology, some of specifications mentioned in this publication are subject to change without notice. Information furnished is believed to be accurate and reliable. ACS assumes no responsibility for any errors or omissions, which may appear in this document. 
